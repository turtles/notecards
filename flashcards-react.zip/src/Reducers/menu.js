import {
	GOTO_NOTECARD_EDITOR, GOTO_QUIZ
} from '../Actions/menu'
import {saveAs} from 'file-saver'

const initialState = {view: 'notecardEditor'};

const menu = (state = initialState, action) => {
	switch (action.type) {

		case GOTO_NOTECARD_EDITOR:
			console.log('meow');
			return {view: 'notecardEditor'};

		case GOTO_QUIZ:
			console.log('alternative meow');
			return {view: 'quiz'};

		default:
			return state;
	}
}

export default menu;
