/*
 * action types
 */

export const GOTO_NOTECARD_EDITOR = 'GOTO_NOTECARD_EDITOR'

/*
 * action creators
 */

export function gotoNotecardEditor() {
  return { type: GOTO_NOTECARD_EDITOR }
}
