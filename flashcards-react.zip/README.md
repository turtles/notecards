## Notecards 

Web app that lets you define notecards and study from them.

Made with the goal of learning Redux.
